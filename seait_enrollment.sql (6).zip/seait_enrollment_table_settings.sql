
-- --------------------------------------------------------

--
-- Table structure for table `settings`
--
-- Creation: Oct 27, 2026 at 05:26 AM
-- Last update: Nov 04, 2026 at 01:17 AM
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `key` varchar(50) NOT NULL,
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `settings`:
--

--
-- Dumping data for table `settings`
--

INSERT DELAYED IGNORE INTO `settings` (`key`, `value`) VALUES
('enrollment_cap', '30500'),
('enrollment_close', '2026-11-30'),
('enrollment_enabled', '1'),
('enrollment_open', '2025-06-01'),
('school_year', '1st Semester S.Y. 2025-2026');
