
-- --------------------------------------------------------

--
-- Table structure for table `student_ids`
--
-- Creation: Nov 03, 2026 at 05:22 AM
-- Last update: Nov 04, 2026 at 02:34 AM
--

DROP TABLE IF EXISTS `student_ids`;
CREATE TABLE IF NOT EXISTS `student_ids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicant_id` int(11) NOT NULL,
  `student_no` varchar(30) NOT NULL,
  `emergency_name` varchar(120) NOT NULL,
  `emergency_address` varchar(180) NOT NULL,
  `emergency_phone` varchar(30) NOT NULL,
  `blood_type` varchar(10) DEFAULT NULL,
  `signature_path` varchar(255) NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `applicant_id` (`applicant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `student_ids`:
--   `applicant_id`
--       `applicants` -> `id`
--

--
-- Dumping data for table `student_ids`
--

INSERT DELAYED IGNORE INTO `student_ids` (`id`, `applicant_id`, `student_no`, `emergency_name`, `emergency_address`, `emergency_phone`, `blood_type`, `signature_path`, `submitted_at`) VALUES
(4, 15, '2026-00015', 'noel galigao', 'glamang', '+639641494959', 'A+', 'uploads/15/id_signature_1793684957_cedb295e.png', '2026-11-03 05:49:17'),
(7, 25, '2026-00015', 'noel galigao', 'glamang', '+639641494959', 'A+', 'uploads/15/id_signature_1793684957_cedb295e.png', '2026-11-03 06:42:28'),
(9, 32, '2026-00015', 'noel galigao', 'glamang', '+639641494959', 'A+', 'uploads/15/id_signature_1793684957_cedb295e.png', '2026-11-03 14:11:32'),
(10, 33, '2026-00015', 'noel galigao', 'glamang', '+639641494959', 'A+', 'uploads/15/id_signature_1793684957_cedb295e.png', '2026-11-03 16:25:15'),
(11, 34, '2026-00034', 'juan', 'polomlok', '+639384324234', 'A+', 'uploads/34/id_signature_1793729957_b816bfaf.png', '2026-11-03 18:19:17'),
(12, 35, '2026-00034', 'juan', 'polomlok', '+639384324234', 'A+', 'uploads/34/id_signature_1793729957_b816bfaf.png', '2026-11-03 18:23:48'),
(13, 36, '2026-00034', 'juan', 'polomlok', '+639384324234', 'A+', 'uploads/34/id_signature_1793729957_b816bfaf.png', '2026-11-03 18:35:16'),
(14, 37, '2026-00034', 'juan', 'polomlok', '+639384324234', 'A+', 'uploads/34/id_signature_1793729957_b816bfaf.png', '2026-11-03 18:36:58'),
(15, 38, '2026-00038', 'mama jhon', 'sdfsdf', '+639641494959', 'A-', 'uploads/38/id_signature_1793731216_b94180dc.png', '2026-11-03 18:40:16'),
(16, 39, '2026-00038', 'mama jhon', 'sdfsdf', '+639641494959', 'A-', 'uploads/38/id_signature_1793731216_b94180dc.png', '2026-11-03 18:43:50'),
(17, 40, '2026-00040', 'older mom', 'polomlok', '+639423432432', 'A+', 'uploads/40/id_signature_1793732129_1a7365a7.png', '2026-11-03 18:55:29'),
(18, 30034, '2026-30034', 'final mom', 'polomlok', '+639842938243', 'AB+', 'uploads/30034/id_signature_1793754693_8b9800d8.png', '2026-11-04 01:11:33'),
(19, 30035, '2026-30034', 'final mom', 'polomlok', '+639842938243', 'AB+', 'uploads/30034/id_signature_1793754693_8b9800d8.png', '2026-11-04 01:18:39'),
(20, 30036, '2026-30036', 'tr niel mother', 'polomlok', '+639482391231', 'A+', 'uploads/30036/id_signature_1793759664_7182d112.png', '2026-11-04 02:34:24');
