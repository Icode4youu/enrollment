
-- --------------------------------------------------------

--
-- Table structure for table `payments`
--
-- Creation: Nov 03, 2026 at 11:38 PM
-- Last update: Nov 04, 2026 at 02:36 AM
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `applicant_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 500.00,
  `ref_no` varchar(60) DEFAULT NULL,
  `receipt_doc` int(11) DEFAULT NULL,
  `status` enum('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `applicant_id` (`applicant_id`),
  KEY `idx_ref` (`ref_no`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `payments`:
--   `applicant_id`
--       `applicants` -> `id`
--

--
-- Dumping data for table `payments`
--

INSERT DELAYED IGNORE INTO `payments` (`id`, `applicant_id`, `amount`, `ref_no`, `receipt_doc`, `status`, `remarks`, `created_at`) VALUES
(1, 3, 500.00, '123652356172352', 5, 'confirmed', NULL, '2026-10-27 05:42:59'),
(2, 4, 500.00, '324234324', 10, 'confirmed', NULL, '2026-10-27 05:58:00'),
(3, 5, 500.00, '', 14, 'confirmed', NULL, '2026-10-27 06:21:27'),
(4, 12, 500.00, '213123213', 21, 'confirmed', NULL, '2026-10-27 07:01:10'),
(5, 13, 500.00, '', 26, 'pending', NULL, '2026-11-01 01:41:29'),
(6, 14, 500.00, '423423423', 31, 'confirmed', '', '2026-11-02 13:43:37'),
(7, 15, 500.00, '3242423423', 36, 'confirmed', '', '2026-11-03 05:04:37'),
(12, 25, 350.00, '89235347589345739', 91, 'confirmed', '', '2026-11-03 06:42:43'),
(14, 32, 350.00, '23423423432', 111, 'confirmed', '', '2026-11-03 15:40:17'),
(15, 33, 350.00, '3563563563', 119, 'confirmed', '', '2026-11-03 16:26:25'),
(16, 34, 500.00, '3243423', 124, 'confirmed', '', '2026-11-03 18:18:37'),
(17, 35, 350.00, '342432', 133, 'confirmed', '', '2026-11-03 18:23:58'),
(18, 36, 350.00, '23423423', 141, 'pending', NULL, '2026-11-03 18:35:27'),
(19, 37, 350.00, '', 149, 'pending', NULL, '2026-11-03 18:37:03'),
(20, 38, 500.00, '32874234234', 154, 'confirmed', '', '2026-11-03 18:39:47'),
(21, 39, 350.00, '12312312321', 163, 'confirmed', '', '2026-11-03 18:44:01'),
(22, 40, 500.00, '534534534534', 167, 'confirmed', '', '2026-11-03 18:55:01'),
(23, 30034, 500.00, '423423432', 173, 'confirmed', '', '2026-11-04 01:10:59'),
(24, 30035, 350.00, '423423423', 182, 'confirmed', '', '2026-11-04 01:18:50'),
(25, 30036, 500.00, '123123123', 187, 'confirmed', '', '2026-11-04 02:33:58');
