
-- --------------------------------------------------------

--
-- Table structure for table `course_requests`
--
-- Creation: Nov 03, 2026 at 06:14 AM
-- Last update: Nov 04, 2026 at 02:37 AM
--

DROP TABLE IF EXISTS `course_requests`;
CREATE TABLE IF NOT EXISTS `course_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `current_course` varchar(100) NOT NULL,
  `requested_course` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `status` enum('pending','approved','declined','consumed') NOT NULL DEFAULT 'pending',
  `remarks` varchar(255) DEFAULT NULL,
  `decided_by` int(11) DEFAULT NULL,
  `decided_at` timestamp NULL DEFAULT NULL,
  `new_applicant_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `applicant_id` (`applicant_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `course_requests`:
--   `user_id`
--       `users` -> `id`
--   `applicant_id`
--       `applicants` -> `id`
--

--
-- Dumping data for table `course_requests`
--

INSERT DELAYED IGNORE INTO `course_requests` (`id`, `user_id`, `applicant_id`, `current_course`, `requested_course`, `reason`, `status`, `remarks`, `decided_by`, `decided_at`, `new_applicant_id`, `created_at`) VALUES
(4, 18, 15, 'BSIT', 'BSCrim', 'hahaahhaha', 'consumed', '', 16, '2026-11-03 06:38:23', 25, '2026-11-03 06:38:14'),
(6, 18, 25, 'BSCrim', 'BSIT', 'asdadsa', 'consumed', '', 16, '2026-11-03 14:11:07', 32, '2026-11-03 14:10:20'),
(7, 18, 32, 'BSIT', 'BSCrim', 'kdajfakfdajfa', 'consumed', '', 16, '2026-11-03 16:15:45', 33, '2026-11-03 16:15:30'),
(8, 35, 34, 'BSIT', 'BSCrim', 'kapoy itt', 'consumed', '', 16, '2026-11-03 18:23:33', 35, '2026-11-03 18:22:55'),
(9, 35, 35, 'BSCrim', 'BSIT', 'adfsdfsd', 'consumed', '', 16, '2026-11-03 18:35:11', 36, '2026-11-03 18:35:02'),
(10, 35, 36, 'BSIT', 'BSCrim', 'qddasd', 'consumed', '', 16, '2026-11-03 18:36:51', 37, '2026-11-03 18:36:45'),
(11, 36, 38, 'BSIT', 'BSCrim', 'fwefwefw', 'consumed', '', 16, '2026-11-03 18:42:39', 39, '2026-11-03 18:42:33'),
(12, 30036, 30034, 'BSIT', 'BSCrim', 'kapoy it', 'consumed', '', 16, '2026-11-04 01:18:29', 30035, '2026-11-04 01:18:15'),
(13, 30037, 30036, 'BSIT', 'BSCrim', 'kapoy it', 'approved', '', 16, '2026-11-04 02:37:44', NULL, '2026-11-04 02:37:32');
