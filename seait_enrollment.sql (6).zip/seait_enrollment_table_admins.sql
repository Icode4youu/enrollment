
-- --------------------------------------------------------

--
-- Table structure for table `admins`
--
-- Creation: Oct 27, 2026 at 05:26 AM
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `admins`:
--

--
-- Dumping data for table `admins`
--

INSERT DELAYED IGNORE INTO `admins` (`id`, `username`, `password_hash`, `full_name`) VALUES
(1, 'admin', '$2y$10$HhgaUwal.X0KbevcIhxGc.QNSv7dfRRL1CtqXQChoi9nDdY3RnFmm', 'Registrar Admin');
