
-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--
-- Creation: Oct 27, 2026 at 05:26 AM
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE IF NOT EXISTS `teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `teachers`:
--

--
-- Dumping data for table `teachers`
--

INSERT DELAYED IGNORE INTO `teachers` (`id`, `name`) VALUES
(10, 'DELA CRUZ'),
(2, 'DUMAN-AG'),
(11, 'FLORES'),
(8, 'GARCIA'),
(4, 'JUKILA'),
(1, 'LUCTAWA'),
(3, 'MAVILA'),
(12, 'RAMOS'),
(7, 'REYES'),
(6, 'SANTOS'),
(5, 'SONGCO'),
(13, 'TORRES'),
(9, 'VILLANUEVA');
